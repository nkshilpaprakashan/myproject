const express=require('express')
const router=express.Router()

const userController=require('../controllers/userController')



router.get('/',userController.userhome)

router.get('/userlogin',userController.userLogin)

router.post('/homeuservalidation',userController.homeuserValidation)

router.get('/userlogin/usersignup', userController.userSignup)

router.get('/userlogin/usersignup/register', userController.userRegister)

router.post('/userlogin/usersignup/register', userController.userRegistered)

// router.get('/userlogin/loginuser', userController.loginUser) 

router.get('/userlogout',userController.userLogout)

module.exports=router