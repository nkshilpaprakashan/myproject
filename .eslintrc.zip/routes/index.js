const express=require('express')
const router=express.Router()
const upload = require('../config/multer')
const adminController=require('../controllers/adminController')


router.get('/adminloginpage',adminController.login)

router.post('/validation',adminController.validation)

router.get('/adminloginpage/Dashboard',adminController.adminDashboard)

router.get('/adminloginpage/adminLogout',adminController.adminLogout)

router.get('/adminloginpage/Dashboard/customers', adminController.customers)

router.get('/adminloginpage/Dashboard/customers/blockuser/:id',adminController.blockuser)

router.get('/adminloginpage/Dashboard/customers/unblockuser/:id',adminController.unblockuser)

router.get('/adminloginpage/Dashboard/customers/edits/:id',adminController.customerEdit)

router.post('/adminloginpage/Dashboard/customers/updateUser/:id',adminController.updateCustomer)

router.get('/adminloginpage/Dashboard/customers/delete/:id',adminController.deleteCustomer)

router.get('/adminloginpage/Dashboard/products', adminController.products)

router.get('/adminloginpage/Dashboard/products/addproduct', adminController.addproduct)

router.post('/adminloginpage/Dashboard/products/addproduct/saveproduct',upload.single('image'), adminController.saveProduct)

router.get('/adminloginpage/Dashboard/categories',adminController.categories)

router.get('/adminloginpage/Dashboard/categories/addcategory',adminController.addcategory)

router.post('/adminloginpage/Dashboard/categories/addcategory/createCategory',adminController.createCategory)








module.exports=router