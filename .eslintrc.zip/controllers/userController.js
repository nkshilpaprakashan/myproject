const userCollection = require('../models/userRegister')



// get
function userhome(req, res) {

    res.render('userhome')
}


// get
function userLogin(req, res) {
    if (req.session.useranything) {
        res.redirect('/')
    } else {

        res.render('userlogin', {wrong: req.session.validationpassword});
        req.session.destroy()
    }
}

// post
async function homeuserValidation(req, res) {
    try {
        const email = req.body.email;
        const password = req.body.password;

        console.log(`${email} and password is ${password}`)

        const userdata = await userCollection.findOne({email: email})
        // res.send(userdata)
        console.log(userdata)

        if (userdata.password === password) {
            req.session.useranything = true
            res.redirect('/')
        } else {
            req.session.validationpassword = true
            res.redirect('/userlogin')
            // res.send("password incorrect ");
        }
    } catch (error) {
        req.session.validationpassword = true
        res.redirect('/userlogin')
        // res.status(400).send("Invalid login details");
    }
}


// get
function userSignup(req, res) {
    res.render('userregistration')
}

function userRegister(req, res) {
    res.render('userregistration')
}

async function userRegistered(req, res) {
    try {

        const password = req.body.password;
        const cpassword = req.body.confirmpassword;


        // console.log(req.body.first_name)
        // // res.send(req.body.first_name)
        // res.send(req.body.last_name)


        if (password === cpassword) {

            const registeruser = new userCollection({
                first_name: req.body.first_name,
                last_name: req.body.last_name,
                phonenumber: req.body.phonenumber,
                alternative_phonenumber: req.body.alternative_phonenumber,

                houseno: req.body.houseno,
                area: req.body.area,
                pincode: req.body.pincode,
                place: req.body.place,
                state: req.body.state,
                country: req.body.country,
                email: req.body.email,
                password: password,
                confirmpassword: cpassword

            })

            await registeruser.save()
            res.status(201).redirect('/userlogin');

        } else { // res.send(userregistration)
            res.render('userregistration', {check: "* Password are not matching *"})
        }

    } catch (error) {
        res.status(400).send(error);


    }

}


function userLogout(req, res) {
    req.session.destroy()
    res.redirect('/')

}


module.exports = {
    userhome,
    userLogin,
    homeuserValidation,
    userSignup,
    userRegister,
    userRegistered,
    userLogout
}
