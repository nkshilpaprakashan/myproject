const userCollection=require('../models/userRegister')
const Product=require('../models/products')
const Category=require('../models/category')
const Group=require('../models/group')

var objectId=require('mongodb').ObjectId 

function login(req, res) {
    if (req.session.admin) {
        res.redirect('/adminloginpage/Dashboard')
    } else {


        res.render('index', {wrong: req.session.adminanything});
        req.session.destroy()
    }

}


async function adminDashboard (req, res) {
    if(req.session.admin){
      let userdata=await userCollection.find()
      let categorydata=await Category.find()
      res.render('admindashboard',{fulldata:userdata,categorydata:categorydata});
    }else{
      res.redirect('/adminloginpage')
    }
   }


   function validation(req, res){
    let adminEmail='admin@gmail.com'
    let adminPassword='1'
    if(req.body.email===adminEmail&&req.body.password===adminPassword){
      req.session.admin=true
      res.redirect('/adminloginpage/Dashboard')
    }else{
      req.session.adminanything=true
      res.redirect('/adminloginpage')
    }
  }

 function adminLogout(req, res){
    req.session.destroy()
      res.redirect('/adminloginpage')
   }

   async function customers(req, res){

    if(req.session.admin){
      let userdata=await userCollection.find()
      res.render('customerPage',{fulldata:userdata});
    }else{
      res.redirect('/adminloginpage',)
    }
   }


   async function blockuser(req, res){
    try {
        await userCollection.findByIdAndUpdate({ _id: req.params.id }, { $set: { isBlocked: true } }).then(() => {
            res.redirect('/adminloginpage/Dashboard/customers');
        });
    } catch (error) {
        console.log(error.message);

    }
}
async function unblockuser(req, res){
    try {
      await userCollection.updateOne({ _id: req.params.id }, { $set: { isBlocked: false } }).then(() => {
        res.redirect('/adminloginpage/Dashboard/customers');
      });
    } catch (error) {
      console.log(error.message);
    }
}


   async function customerEdit(req,res){
    let userid=req.params.id
     // res.render('editpage')
     userCollection.findByIdAndUpdate({_id:objectId(userid)},req.body,{new:true},(err,docs)=>{
       if(err){
           console.log("no edit")
           
       }else{
           console.log("updated")
           res.render('editpage',{userCollection:docs})
           
       }
     })
   }

   async function updateCustomer(req,res){

    let userid=req.params.id
    userCollection.findByIdAndUpdate({_id:objectId(userid)},req.body,(err)=>{
  
        if(err){
            console.log("no edit")
            
        }else{
          
            console.log("updated")
            res.redirect('/adminloginpage/Dashboard/customers')
            
        }
  })
  }


  async function deleteCustomer(req,res){
    req.session.delete=req.params.id
    await userCollection.deleteOne({_id:objectId(req.session.delete)})
    res.redirect('/adminloginpage/Dashboard/customers')
  }

   async function products (req,res){
    if(req.session.admin){
      let productdata=await Product.find()
      
      res.render('productPage',{productdata:productdata});
    }else{
      res.redirect('/adminloginpage',)
    }
   }


   


   async function addproduct(req,res){
    if(req.session.admin){
      let groupdata=await Group.find()
      let categorydata=await Category.find()
      res.render('addProductpage',{groupdata:groupdata,categorydata:categorydata})
    }else{
      res.redirect('/adminloginpage',)
    }
   
   }


   async function saveProduct(req,res){
    
    try {
   
      const product = new Product({
        item_code: req.body.item_code,
        item_name: req.body.item_name,
        product_descriptio:req.body.product_description,
        groupName:req.body.groupName,
        categoryName:req.body.categoryName,
        size:req.body.size,
        price:req.body.price,
        mrp:req.body.mrp,
        available_quantity:req.body.available_quantity,
        product_unit:req.body.product_unit,
        percentage_discount:req.body.percentage_discount,
        image:req.file.filename
      })
      console.log(req.body.groupName)
      console.log(req.body.categoryName)
     
      await product.save()
     
      res.status(201).redirect('/adminloginpage/Dashboard/products/addproduct');
    
      
      
    }

   catch (error) {

      res.status(400).send(error);


  }
}


async function categories (req,res){
  if(req.session.admin){
    let categorydata=await Category.find()
    res.render('categoryPage',{categorydata:categorydata});
  }else{
    res.redirect('/adminloginpage',)
  }
 }




   async function addcategory(req,res){
    if(req.session.admin){
      let groupdata=await Group.find()
      console.log(groupdata)

      res.render('addCategorypage',{group:groupdata});
    }else{
      res.redirect('/adminloginpage',)
    }
    
    }

    async function createCategory(req,res){
      try {
     
        const category = new Category({
          groupName: req.body.groupName,
          categoryName: req.body.categoryName,
        })
       
        await category.save()
       
        res.status(201).redirect('/adminloginpage/Dashboard/categories/addcategory');
      
        
        
      }

     catch (error) {

        res.status(400).send(error);


    }
  }
     


    


   



module.exports = {
    login,
    adminDashboard,
    validation,
    adminLogout,
    customers,
    products,
    addproduct,
    categories,
    addcategory,
    customerEdit,
    updateCustomer,
    deleteCustomer,
    blockuser,
    unblockuser,
    createCategory,
    saveProduct
   
}
